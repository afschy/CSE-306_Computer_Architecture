g++ assembler.cpp -o assembler
./assembler
rm assembler